"""
Figuras del Capítulo 11: Modelo de Rescorla y Wagner
Paleta del libro: azul #2C5282, naranja #C05621, verde #276749, gris #718096
Fondo blanco, fuentes serif
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams

# ── Estilo global del libro ──
AZUL = '#2C5282'
NARANJA = '#C05621'
VERDE = '#276749'
GRIS = '#718096'
rcParams['font.family'] = 'serif'
rcParams['font.size'] = 11
rcParams['axes.linewidth'] = 0.8
rcParams['axes.edgecolor'] = GRIS
rcParams['xtick.color'] = GRIS
rcParams['ytick.color'] = GRIS
rcParams['figure.facecolor'] = 'white'
rcParams['axes.facecolor'] = 'white'
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.25
rcParams['grid.color'] = GRIS

def rw_update(V_dict, present, alpha, betas, R):
    """Single trial R-W update. V_dict: {name: value}, present: list of names."""
    V_total = sum(V_dict[s] for s in present)
    error = R - V_total
    for s in present:
        V_dict[s] += alpha * betas[s] * error
    return V_dict, error

def run_protocol(phases, alpha, betas, stim_names):
    """Run multi-phase protocol. phases: list of (n_trials, present_list, R)."""
    V = {s: 0.0 for s in stim_names}
    history = {s: [] for s in stim_names}
    for n_trials, present, R in phases:
        for _ in range(n_trials):
            for s in stim_names:
                history[s].append(V[s])
            V, _ = rw_update(V, present, alpha, betas, R)
    for s in stim_names:
        history[s].append(V[s])
    return history

def save(fig, name):
    fig.savefig(f'/home/claude/{name}.svg', bbox_inches='tight', dpi=150)
    fig.savefig(f'/home/claude/{name}.png', bbox_inches='tight', dpi=200)
    plt.close(fig)
    print(f'  ✓ {name}')

# ════════════════════════════════════════════
# FIGURA 11.1 — Ensombrecimiento
# ════════════════════════════════════════════
print('Generando figuras...')
alpha = 0.2
betas_comp = {'tono': 0.4, 'luz': 0.2}
betas_t = {'tono': 0.4}
betas_l = {'luz': 0.2}
N = 60

h_comp = run_protocol([(N, ['tono', 'luz'], 1.0)], alpha, betas_comp, ['tono', 'luz'])
h_tono = run_protocol([(N, ['tono'], 1.0)], alpha, betas_t, ['tono'])
h_luz  = run_protocol([(N, ['luz'], 1.0)], alpha, betas_l, ['luz'])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2), sharey=True)
ens = np.arange(N+1)
ax1.plot(ens, h_comp['tono'], color=AZUL, lw=2, label='$V_{tono}$')
ax1.plot(ens, h_comp['luz'], color=NARANJA, lw=2, label='$V_{luz}$')
vtot = np.array(h_comp['tono']) + np.array(h_comp['luz'])
ax1.plot(ens, vtot, color=GRIS, lw=1.5, ls='--', label='$V_{total}$')
ax1.set_title('Grupo compuesto (tono + luz)', fontsize=11)
ax1.set_xlabel('Ensayos'); ax1.set_ylabel('Valor predictivo $V$')
ax1.legend(fontsize=9, loc='center right'); ax1.set_ylim(-0.05, 1.1)

ax2.plot(ens, h_tono['tono'], color=AZUL, lw=2, label='Tono solo')
ens_l = np.arange(N+1)
ax2.plot(ens_l, h_luz['luz'], color=NARANJA, lw=2, label='Luz sola')
ax2.set_title('Grupos control (individual)', fontsize=11)
ax2.set_xlabel('Ensayos')
ax2.legend(fontsize=9, loc='center right'); ax2.set_ylim(-0.05, 1.1)

fig.suptitle('Figura 11.1 — Ensombrecimiento', fontsize=12, fontweight='bold', y=1.02)
fig.tight_layout()
save(fig, 'fig_11_1_ensombrecimiento')

# ════════════════════════════════════════════
# FIGURA 11.2 — Bloqueo
# ════════════════════════════════════════════
alpha = 0.2
betas_blk = {'tono': 0.4, 'luz': 0.4}
N1, N2 = 60, 60

# Grupo bloqueo
h_blk = run_protocol([
    (N1, ['tono'], 1.0),
    (N2, ['tono', 'luz'], 1.0)
], alpha, betas_blk, ['tono', 'luz'])

# Grupo control
h_ctrl = run_protocol([
    (N2, ['tono', 'luz'], 1.0)
], alpha, betas_blk, ['tono', 'luz'])

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7), sharex=False)
ens1 = np.arange(N1 + N2 + 1)
ax1.plot(ens1, h_blk['tono'], color=AZUL, lw=2, label='$V_{tono}$')
ax1.plot(ens1, h_blk['luz'], color=NARANJA, lw=2, label='$V_{luz}$ (bloqueada)')
ax1.axvline(x=N1 - 0.5, color=VERDE, ls=':', lw=1.5, label='Inicio Fase 2')
ax1.set_title('Grupo bloqueo', fontsize=11)
ax1.set_ylabel('Valor predictivo $V$'); ax1.set_ylim(-0.05, 1.1)
ax1.legend(fontsize=9); ax1.set_xlabel('Ensayos')

ens2 = np.arange(N2 + 1)
ax2.plot(ens2, h_ctrl['tono'], color=AZUL, lw=2, label='$V_{tono}$')
ax2.plot(ens2, h_ctrl['luz'], color=NARANJA, lw=2, label='$V_{luz}$')
ax2.set_title('Grupo control (sin Fase 1)', fontsize=11)
ax2.set_xlabel('Ensayos'); ax2.set_ylabel('Valor predictivo $V$')
ax2.set_ylim(-0.05, 1.1); ax2.legend(fontsize=9)

fig.suptitle('Figura 11.2 — Bloqueo', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_2_bloqueo')

# ════════════════════════════════════════════
# FIGURA 11.3 — Sobreexpectación
# ════════════════════════════════════════════
alpha = 0.2
betas_se = {'tono': 0.5, 'luz': 0.5}
N_ind, N_comp = 60, 60

h_se = run_protocol([
    (N_ind, ['tono'], 1.0),
    (N_ind, ['luz'], 1.0),
    (N_comp, ['tono', 'luz'], 1.0)
], alpha, {'tono': 0.5, 'luz': 0.0}, ['tono', 'luz'])
# Need to redo properly - phases 1 and 2 train separately
V = {'tono': 0.0, 'luz': 0.0}
ht, hl = [], []
betas = {'tono': 0.5, 'luz': 0.5}
# Phase 1: tono solo
for i in range(N_ind):
    ht.append(V['tono']); hl.append(V['luz'])
    err = 1.0 - V['tono']
    V['tono'] += alpha * betas['tono'] * err
# Phase 2: luz sola
for i in range(N_ind):
    ht.append(V['tono']); hl.append(V['luz'])
    err = 1.0 - V['luz']
    V['luz'] += alpha * betas['luz'] * err
# Phase 3: compuesto
for i in range(N_comp):
    ht.append(V['tono']); hl.append(V['luz'])
    vtot = V['tono'] + V['luz']
    err = 1.0 - vtot
    V['tono'] += alpha * betas['tono'] * err
    V['luz'] += alpha * betas['luz'] * err
ht.append(V['tono']); hl.append(V['luz'])

fig, ax = plt.subplots(figsize=(10, 4.5))
total_ens = np.arange(len(ht))
ax.plot(total_ens, ht, color=AZUL, lw=2, label='$V_{tono}$')
ax.plot(total_ens, hl, color=NARANJA, lw=2, label='$V_{luz}$')
ax.axvline(x=N_ind - 0.5, color=GRIS, ls=':', lw=1, alpha=0.7)
ax.axvline(x=2*N_ind - 0.5, color=VERDE, ls=':', lw=1.5, label='Inicio Fase 3')
ax.text(N_ind/2, 1.08, 'Fase 1\n(tono solo)', ha='center', fontsize=9, color=GRIS)
ax.text(N_ind + N_ind/2, 1.08, 'Fase 2\n(luz sola)', ha='center', fontsize=9, color=GRIS)
ax.text(2*N_ind + N_comp/2, 1.08, 'Fase 3\n(compuesto)', ha='center', fontsize=9, color=GRIS)
ax.set_xlabel('Ensayos'); ax.set_ylabel('Valor predictivo $V$')
ax.set_ylim(-0.05, 1.2); ax.legend(fontsize=9, loc='center right')
fig.suptitle('Figura 11.3 — Sobreexpectación', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_3_sobreexpectacion')

# ════════════════════════════════════════════
# FIGURA 11.4 — Creación de inhibidor condicionado
# ════════════════════════════════════════════
alpha = 0.2
betas_inh = {'tono': 0.5, 'luz': 0.5}
V = {'tono': 0.0, 'luz': 0.0}
ht, hl = [], []
N_phase = 60
# Intercalated: T+ and TL- (alternating)
for i in range(N_phase):
    ht.append(V['tono']); hl.append(V['luz'])
    # Trial A: T+ (tono solo, reforzado)
    err_a = 1.0 - V['tono']
    V['tono'] += alpha * betas_inh['tono'] * err_a
    # Trial B: TL- (compuesto, no reforzado)
    ht.append(V['tono']); hl.append(V['luz'])
    vtot = V['tono'] + V['luz']
    err_b = 0.0 - vtot
    V['tono'] += alpha * betas_inh['tono'] * err_b
    V['luz'] += alpha * betas_inh['luz'] * err_b
ht.append(V['tono']); hl.append(V['luz'])

fig, ax = plt.subplots(figsize=(8, 4.5))
ens = np.arange(len(ht))
ax.plot(ens, ht, color=AZUL, lw=2, label='$V_{tono}$ (excitador)')
ax.plot(ens, hl, color=NARANJA, lw=2, label='$V_{luz}$ (inhibidor)')
ax.axhline(y=0, color=GRIS, lw=0.8, ls='-', alpha=0.5)
ax.set_xlabel('Ensayos (T+ y TL− intercalados)'); ax.set_ylabel('Valor predictivo $V$')
ax.set_ylim(-0.7, 1.2); ax.legend(fontsize=9)
fig.suptitle('Figura 11.4 — Creación de un inhibidor condicionado', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_4_inhibidor')

# ════════════════════════════════════════════
# FIGURA 11.5 — Prueba de sumación
# ════════════════════════════════════════════
# After creating inhibitor, test compound LX vs X alone
# Simplified: show V_luz acquiring negative value, then summation effect
V_exc = 0.8  # excitador X entrenado aparte
V_inh_values = [0, -0.2, -0.4, -0.5]  # diferentes niveles de inhibición

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))
# Panel 1: Creación del inhibidor (V_luz descendiendo)
ens_inh = np.arange(len(hl))
ax1.plot(ens_inh, hl, color=NARANJA, lw=2)
ax1.axhline(y=0, color=GRIS, lw=0.8, ls='-', alpha=0.5)
ax1.set_xlabel('Ensayos de entrenamiento'); ax1.set_ylabel('$V_{luz}$')
ax1.set_title('Adquisición de valor inhibitorio', fontsize=10)
ax1.set_ylim(-0.7, 0.1)

# Panel 2: Sumación — barras
conditions = ['X solo', 'X + L (inhibidor)', 'X + N (neutral)']
vtotals = [V_exc, V_exc + (-0.5), V_exc + 0.0]
colors = [AZUL, NARANJA, GRIS]
bars = ax2.bar(conditions, vtotals, color=colors, width=0.5, edgecolor='white', linewidth=1.5)
ax2.set_ylabel('$V_{total}$ (predicción)'); ax2.set_ylim(0, 1.0)
ax2.set_title('Prueba de sumación', fontsize=10)
for bar, val in zip(bars, vtotals):
    ax2.text(bar.get_x() + bar.get_width()/2, val + 0.03, f'{val:.1f}', ha='center', fontsize=10)

fig.suptitle('Figura 11.5 — Prueba de sumación', fontsize=12, fontweight='bold', y=1.02)
fig.tight_layout()
save(fig, 'fig_11_5_sumacion')

# ════════════════════════════════════════════
# FIGURA 11.6 — Prueba de retardo
# ════════════════════════════════════════════
alpha = 0.2
betas_ret = {'luz': 0.5}
N_ret = 40

# Control: neutral starts at 0
h_ctrl_ret = run_protocol([(N_ret, ['luz'], 1.0)], alpha, betas_ret, ['luz'])

# Experimental: inhibitor starts at -0.5
V_inh = {'luz': -0.5}
h_exp = []
for i in range(N_ret):
    h_exp.append(V_inh['luz'])
    err = 1.0 - V_inh['luz']
    V_inh['luz'] += alpha * betas_ret['luz'] * err
h_exp.append(V_inh['luz'])

fig, ax = plt.subplots(figsize=(8, 4.5))
ens = np.arange(N_ret + 1)
ax.plot(ens, h_ctrl_ret['luz'], color=AZUL, lw=2, label='Control (neutral, $V_0 = 0$)')
ax.plot(ens, h_exp, color=NARANJA, lw=2, label='Inhibidor ($V_0 = -0.5$)')
ax.axhline(y=0, color=GRIS, lw=0.8, ls='-', alpha=0.5)
ax.set_xlabel('Ensayos de adquisición'); ax.set_ylabel('Valor predictivo $V$')
ax.set_ylim(-0.6, 1.1); ax.legend(fontsize=9)
fig.suptitle('Figura 11.6 — Prueba de retardo', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_6_retardo')

# ════════════════════════════════════════════
# FIGURA 11.7 — No extinción de inhibición
# ════════════════════════════════════════════
alpha = 0.2
N_ext = 50

# Excitator extinction: V starts at 1.0, R=0
V_exc_ext = [1.0]
v = 1.0
for i in range(N_ext):
    v += alpha * 0.5 * (0 - v)
    V_exc_ext.append(v)

# Inhibitor "extinction": V starts at -0.5, R=0, presented alone
# Model predicts it should go to 0
V_inh_ext_model = [-0.5]
v = -0.5
for i in range(N_ext):
    v += alpha * 0.5 * (0 - v)
    V_inh_ext_model.append(v)

# Empirical reality: inhibitor stays negative
V_inh_ext_real = [-0.5] * (N_ext + 1)

fig, ax = plt.subplots(figsize=(8, 4.5))
ens = np.arange(N_ext + 1)
ax.plot(ens, V_exc_ext, color=AZUL, lw=2, label='Extinción de excitador ($V \\to 0$)')
ax.plot(ens, V_inh_ext_model, color=GRIS, lw=1.5, ls='--', label='Predicción R-W para inhibidor')
ax.plot(ens, V_inh_ext_real, color=NARANJA, lw=2, label='Resultado empírico: inhibidor no se extingue')
ax.axhline(y=0, color=GRIS, lw=0.8, ls='-', alpha=0.3)
ax.set_xlabel('Ensayos de extinción'); ax.set_ylabel('Valor predictivo $V$')
ax.set_ylim(-0.7, 1.1); ax.legend(fontsize=9, loc='center right')
fig.suptitle('Figura 11.7 — No extinción de la inhibición condicionada', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_7_no_extincion_inhibicion')

# ════════════════════════════════════════════
# FIGURA 11.8 — Inhibición latente
# ════════════════════════════════════════════
alpha = 0.2
beta = 0.5
N_pre = 60
N_acq = 60

# Control: no pre-exposure, direct acquisition
h_ctrl_li = run_protocol([(N_acq, ['X'], 1.0)], alpha, {'X': beta}, ['X'])

# Pre-exposed: R-W predicts same curve (which is the failure)
h_rw_pred = run_protocol([(N_acq, ['X'], 1.0)], alpha, {'X': beta}, ['X'])

# Empirical reality: slower acquisition (simulated with lower effective beta)
h_emp = run_protocol([(N_acq, ['X'], 1.0)], alpha, {'X': 0.15}, ['X'])

fig, ax = plt.subplots(figsize=(8, 4.5))
ens = np.arange(N_acq + 1)
ax.plot(ens, h_ctrl_li['X'], color=AZUL, lw=2, label='Control (sin pre-exposición)')
ax.plot(ens, h_rw_pred['X'], color=GRIS, lw=1.5, ls='--', label='Predicción R-W para pre-expuesto')
ax.plot(ens, h_emp['X'], color=NARANJA, lw=2, label='Resultado empírico (pre-expuesto)')
ax.set_xlabel('Ensayos de adquisición (Fase 2)'); ax.set_ylabel('Valor predictivo $V$')
ax.set_ylim(-0.05, 1.1); ax.legend(fontsize=9)
ax.annotate('R-W predice curvas\nidénticas (falla)', xy=(30, 0.95), fontsize=9,
            color=GRIS, fontstyle='italic', ha='center')
fig.suptitle('Figura 11.8 — Inhibición latente', fontsize=12, fontweight='bold', y=1.01)
fig.tight_layout()
save(fig, 'fig_11_8_inhibicion_latente')

print('\n✓ Todas las figuras generadas.')
