"""
Simulador 11.2 — Explorador de Protocolos Rescorla-Wagner
Capítulo 11: Modelo de Rescorla y Wagner

Protocolos: Adquisición simple, Ensombrecimiento, Bloqueo, Sobreexpectación, Desbloqueo
Paleta del libro: azul #2C5282, naranja #C05621, verde #276749, gris #718096
Ejecutar en Google Colab con: Runtime > Run all
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import ipywidgets as widgets
from IPython.display import display, clear_output

# ── Estilo del libro ──
AZUL, NARANJA, VERDE, GRIS = '#2C5282', '#C05621', '#276749', '#718096'
rcParams.update({'font.family': 'serif', 'font.size': 11, 'axes.linewidth': 0.8,
                 'axes.edgecolor': GRIS, 'xtick.color': GRIS, 'ytick.color': GRIS,
                 'axes.grid': True, 'grid.alpha': 0.25, 'grid.color': GRIS,
                 'figure.facecolor': 'white', 'axes.facecolor': 'white'})

def rw_trial(V, present, alpha, betas, R):
    V_total = sum(V[s] for s in present)
    error = R - V_total
    for s in present:
        V[s] += alpha * betas[s] * error
    return error

def run_protocol(protocol_name, alpha, beta_A, beta_B, n_fase, R1=1.0, R2=1.0):
    """Ejecuta un protocolo y devuelve historias de V_A, V_B y metadatos de fases."""
    betas = {'A': beta_A, 'B': beta_B}
    V = {'A': 0.0, 'B': 0.0}
    hA, hB, phase_marks = [], [], []

    if protocol_name == 'Adquisición simple':
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A'], alpha, betas, R1)
        hA.append(V['A']); hB.append(V['B'])
        phase_marks = []

    elif protocol_name == 'Ensombrecimiento':
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A', 'B'], alpha, betas, R1)
        hA.append(V['A']); hB.append(V['B'])
        phase_marks = []

    elif protocol_name == 'Bloqueo':
        # Fase 1: A solo
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A'], alpha, betas, R1)
        phase_marks.append(len(hA) - 0.5)
        # Fase 2: A+B
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A', 'B'], alpha, betas, R2)
        hA.append(V['A']); hB.append(V['B'])

    elif protocol_name == 'Sobreexpectación':
        # Fase 1: A solo
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A'], alpha, betas, R1)
        phase_marks.append(len(hA) - 0.5)
        # Fase 2: B solo
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['B'], alpha, betas, R1)
        phase_marks.append(len(hA) - 0.5)
        # Fase 3: A+B compuesto
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A', 'B'], alpha, betas, R2)
        hA.append(V['A']); hB.append(V['B'])

    elif protocol_name == 'Desbloqueo':
        # Fase 1: A solo con R=1
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A'], alpha, betas, 1.0)
        phase_marks.append(len(hA) - 0.5)
        # Fase 2: A+B con R variable (R2)
        for _ in range(n_fase):
            hA.append(V['A']); hB.append(V['B'])
            rw_trial(V, ['A', 'B'], alpha, betas, R2)
        hA.append(V['A']); hB.append(V['B'])

    return np.array(hA), np.array(hB), phase_marks

# ── Controles ──
w_proto = widgets.Dropdown(options=['Adquisición simple', 'Ensombrecimiento',
                                     'Bloqueo', 'Sobreexpectación', 'Desbloqueo'],
                            value='Bloqueo', description='Protocolo:',
                            style={'description_width': '80px'})
w_alpha  = widgets.FloatSlider(value=0.2, min=0.05, max=0.5, step=0.05,
                                description='α (SBI):', style={'description_width': '80px'})
w_beta_A = widgets.FloatSlider(value=0.4, min=0.1, max=0.9, step=0.05,
                                description='β_A:', style={'description_width': '80px'})
w_beta_B = widgets.FloatSlider(value=0.4, min=0.1, max=0.9, step=0.05,
                                description='β_B:', style={'description_width': '80px'})
w_n      = widgets.IntSlider(value=60, min=10, max=100, step=5,
                              description='Ensayos/fase:', style={'description_width': '80px'})
w_R2     = widgets.FloatSlider(value=1.0, min=0.5, max=2.0, step=0.1,
                                description='R (Fase 2+):', style={'description_width': '80px'})

output = widgets.Output()

DESCRIPCIONES = {
    'Adquisición simple': 'A → SBI. Un estímulo solo, sin competencia.',
    'Ensombrecimiento': 'A+B → SBI. Dos estímulos compiten desde el inicio.',
    'Bloqueo': 'Fase 1: A → SBI | Fase 2: A+B → SBI. A preentrenado bloquea a B.',
    'Sobreexpectación': 'F1: A→SBI | F2: B→SBI | F3: A+B→SBI. Valores bajan en F3.',
    'Desbloqueo': 'F1: A→SBI (R=1) | F2: A+B→SBI (R variable). Cambia R₂ para desbloquear.'
}

def actualizar(_):
    with output:
        clear_output(wait=True)
        proto = w_proto.value
        hA, hB, marks = run_protocol(proto, w_alpha.value, w_beta_A.value,
                                      w_beta_B.value, w_n.value, R2=w_R2.value)
        ens = np.arange(len(hA))

        fig, ax = plt.subplots(figsize=(11, 5))
        ax.plot(ens, hA, color=AZUL, lw=2.5, label='$V_A$')
        if proto != 'Adquisición simple':
            ax.plot(ens, hB, color=NARANJA, lw=2.5, label='$V_B$')
            vtot = hA + hB
            ax.plot(ens, vtot, color=GRIS, lw=1.5, ls='--', label='$V_{total}$')

        for m in marks:
            ax.axvline(x=m, color=VERDE, ls=':', lw=1.5, alpha=0.8)

        ax.axhline(y=0, color=GRIS, lw=0.5, alpha=0.4)
        ax.set_xlabel('Ensayos'); ax.set_ylabel('Valor predictivo $V$')
        ymin = min(min(hA), min(hB)) - 0.1 if proto != 'Adquisición simple' else -0.1
        ax.set_ylim(ymin, max(1.2, max(hA) + 0.15))
        ax.legend(fontsize=10, loc='best')

        desc = DESCRIPCIONES[proto]
        ax.set_title(f'{proto}\n{desc}', fontsize=11, color=GRIS)

        # Valores finales
        txt = f'$V_A$ final = {hA[-1]:.3f}'
        if proto != 'Adquisición simple':
            txt += f'    $V_B$ final = {hB[-1]:.3f}'
        ax.text(0.02, 0.02, txt, transform=ax.transAxes, fontsize=9,
                color=GRIS, verticalalignment='bottom')

        fig.suptitle('Simulador 11.2 — Protocolos Rescorla-Wagner',
                     fontsize=12, fontweight='bold')
        fig.tight_layout()
        plt.show()

for w in [w_proto, w_alpha, w_beta_A, w_beta_B, w_n, w_R2]:
    w.observe(actualizar, names='value')

print("Simulador 11.2 — Explorador de Protocolos Rescorla-Wagner")
print("Selecciona un protocolo y ajusta los parámetros.")
print("En 'Desbloqueo', cambia R(Fase 2+) a 1.5 para ver el efecto.\n")
display(widgets.VBox([w_proto, w_alpha, w_beta_A, w_beta_B, w_n, w_R2]))
display(output)
actualizar(None)
