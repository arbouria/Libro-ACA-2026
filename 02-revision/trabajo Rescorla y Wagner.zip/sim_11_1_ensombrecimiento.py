"""
Simulador 11.1 — Explorador de Ensombrecimiento
Capítulo 11: Modelo de Rescorla y Wagner

Paleta del libro: azul #2C5282, naranja #C05621, verde #276749, gris #718096
Ejecutar en Google Colab con: Runtime > Run all
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import ipywidgets as widgets
from IPython.display import display, clear_output

# ── Estilo del libro ──
AZUL, NARANJA, VERDE, GRIS = '#2C5282', '#C05621', '#276749', '#718096'
rcParams.update({'font.family': 'serif', 'font.size': 11, 'axes.linewidth': 0.8,
                 'axes.edgecolor': GRIS, 'xtick.color': GRIS, 'ytick.color': GRIS,
                 'axes.grid': True, 'grid.alpha': 0.25, 'grid.color': GRIS,
                 'figure.facecolor': 'white', 'axes.facecolor': 'white'})

def simular_ensombrecimiento(alpha, beta_A, beta_B, n_ensayos):
    """Simula ensombrecimiento con el modelo de Rescorla y Wagner."""
    V_A, V_B = 0.0, 0.0
    hist_A, hist_B = [V_A], [V_B]

    for _ in range(n_ensayos):
        V_total = V_A + V_B
        error = 1.0 - V_total
        V_A += alpha * beta_A * error
        V_B += alpha * beta_B * error
        hist_A.append(V_A)
        hist_B.append(V_B)

    return np.array(hist_A), np.array(hist_B)

# ── Controles interactivos ──
w_alpha  = widgets.FloatSlider(value=0.2, min=0.05, max=0.5, step=0.05,
                                description='α (SBI):', style={'description_width': '80px'})
w_beta_A = widgets.FloatSlider(value=0.4, min=0.1, max=0.9, step=0.05,
                                description='β_A:', style={'description_width': '80px'})
w_beta_B = widgets.FloatSlider(value=0.2, min=0.1, max=0.9, step=0.05,
                                description='β_B:', style={'description_width': '80px'})
w_n      = widgets.IntSlider(value=60, min=10, max=100, step=5,
                              description='Ensayos:', style={'description_width': '80px'})

output = widgets.Output()

def actualizar(_):
    with output:
        clear_output(wait=True)
        h_A, h_B = simular_ensombrecimiento(w_alpha.value, w_beta_A.value,
                                             w_beta_B.value, w_n.value)
        ens = np.arange(len(h_A))

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))

        # Panel izquierdo: compuesto
        ax1.plot(ens, h_A, color=AZUL, lw=2, label=f'$V_A$ (β={w_beta_A.value:.2f})')
        ax1.plot(ens, h_B, color=NARANJA, lw=2, label=f'$V_B$ (β={w_beta_B.value:.2f})')
        ax1.plot(ens, h_A + h_B, color=GRIS, lw=1.5, ls='--', label='$V_{total}$')
        ax1.set_xlabel('Ensayos'); ax1.set_ylabel('Valor predictivo $V$')
        ax1.set_ylim(-0.05, 1.15); ax1.set_title('Compuesto A+B → SBI')
        ax1.legend(fontsize=9)

        # Panel derecho: distribución asintótica
        v_a_final, v_b_final = h_A[-1], h_B[-1]
        bars = ax2.bar(['$V_A$', '$V_B$'], [v_a_final, v_b_final],
                       color=[AZUL, NARANJA], width=0.4, edgecolor='white')
        ax2.set_ylim(0, 1.1); ax2.set_ylabel('Valor asintótico')
        ax2.set_title('Distribución del crédito')
        ratio = w_beta_A.value / (w_beta_A.value + w_beta_B.value)
        ax2.axhline(y=ratio, color=VERDE, ls=':', lw=1.5,
                    label=f'β_A/(β_A+β_B) = {ratio:.2f}')
        ax2.legend(fontsize=9)
        for bar, val in zip(bars, [v_a_final, v_b_final]):
            ax2.text(bar.get_x() + bar.get_width()/2, val + 0.03,
                    f'{val:.2f}', ha='center', fontsize=10)

        fig.suptitle('Simulador 11.1 — Ensombrecimiento', fontsize=12, fontweight='bold')
        fig.tight_layout()
        plt.show()

for w in [w_alpha, w_beta_A, w_beta_B, w_n]:
    w.observe(actualizar, names='value')

print("Simulador 11.1 — Explorador de Ensombrecimiento")
print("Mueve los controles para explorar cómo la proporción de saliencias")
print("determina la distribución asintótica del valor predictivo.\n")
display(widgets.VBox([w_alpha, w_beta_A, w_beta_B, w_n]))
display(output)
actualizar(None)
